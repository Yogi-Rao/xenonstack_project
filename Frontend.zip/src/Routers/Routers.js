import React from 'react'
 import { BrowserRouter, Route, Routes } from 'react-router-dom'

import About from '../Pages/About'
import ContactUs from '../Pages/ContactUs'

import Home from '../Pages/Home'
import { Login } from '../Pages/Login'
import Register from '../Pages/Register'
import MainHome from '../Pages/MainHome'

export default function Routers() {
  return (
    <div>
      
        <BrowserRouter>

       
        <Routes>
            <Route path="/" element={<MainHome></MainHome>} />
            <Route path="/register" element={<Register />} />
            <Route path="/contact" element={<ContactUs/>} />
            <Route path="/login" element={<Login />} />
            <Route path="/about" element={<About />} />
         </Routes>
       
        
        
        </BrowserRouter>
    </div>
  )
}
