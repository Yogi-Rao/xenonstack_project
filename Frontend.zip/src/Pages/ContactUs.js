import React from 'react'
import { Row } from 'reactstrap'

import Home from "./Home";
import "../css/contact.css"
 
function ContactUs(props) {
  return (
    <>
    <Home></Home>

    <section>


    <div
  className="contact2"
  style={{
    backgroundImage:
      "url(https://www.wrappixel.com/demos/ui-kit/wrapkit/assets/images/contact/map.jpg)"
  }}
  id="contact"
>
  <div className="container">
    <div className="row contact-container">
      <div className="col-lg-12">
        <div className="card card-shadow border-0 mb-4">
          <div className="row">
            <div className="col-lg-8">
              <div className="contact-box p-4">
                <h4 className="title">Contact Us</h4>
                <form>
                  <div className="row">
                    <div className="col-lg-6">
                      <div className="form-group mt-3">
                        <input
                          className="form-control"
                          type="text"
                          placeholder="name"
                        />
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="form-group mt-3">
                        <input
                          className="form-control"
                          type="text"
                          placeholder="email"
                        />
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="form-group mt-3">
                        <input
                          className="form-control"
                          type="text"
                          placeholder="phone"
                        />
                      </div>
                    </div>
                    <div className="col-lg-6">
                      <div className="form-group mt-3">
                        <input
                          className="form-control"
                          type="text"
                          placeholder="location"
                        />
                      </div>
                    </div>
                    <div className="col-lg-12">
                      <div className="form-group mt-3">
                        <input
                          className="form-control"
                          type="text"
                          placeholder="message"
                        />
                      </div>
                    </div>
                    <div className="col-lg-12">
                      <button
                        type="submit"
                        className="btn btn-danger-gradiant mt-3 mb-3 text-white border-0 py-2 px-3"
                      >
                        <span>
                          {" "}
                          SUBMIT NOW <i className="ti-arrow-right" />
                        </span>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div
              className="col-lg-4 bg-image"
              style={{
                backgroundImage:
                  "url(https://www.wrappixel.com/demos/ui-kit/wrapkit/assets/images/contact/1.jpg)"
              }}
            >
              <div className="detail-box p-4">
                <h5 className="text-white font-weight-light mb-3">ADDRESS</h5>
                <p className="text-white op-7">
                  601 Sherwood Ave.
                  <br /> San Bernandino
                </p>
                <h5 className="text-white font-weight-light mb-3 mt-4">
                  CALL US
                </h5>
                <p className="text-white op-7">
                  251 546 9442
                  <br /> 630 446 8851
                </p>
                <div className="round-social light">
                  <a
                    href="#"
                    className="ml-0 text-decoration-none text-white border border-white rounded-circle"
                  >
                    <i className="icon-social-facebook" />
                  </a>
                  <a
                    href="#"
                    className="text-decoration-none text-white border border-white rounded-circle"
                  >
                    <i className="icon-social-twitter" />
                  </a>
                  <a
                    href="#"
                    className="text-decoration-none text-white border border-white rounded-circle"
                  >
                    <i className="icon-social-youtube" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


      
    </section>




      {/* <header id="contact-header" >
        <div id="contact" className="container align-items-center "  >
          <div className="col m-3">
            <h1 className="mt-2 align-content-center">
              Contact Us
            </h1>
          </div>
        </div>
      </header>
      <div className="container mt-5 align-items-center">


        <h3 style={{ textAlign: 'center' }}>
          Let's Start a Conversation.
        </h3>
        <div className="container-fluid mt-5 row align-items-center">
          <div className="container col-6">
            <form className="text-center border border-light p-5" action="#!">
              <p className="h4 mb-4">Contact us</p>
              <input type="text" id="defaultContactFormName" className="form-control mb-4" placeholder="Name" />
              <input type="email" id="defaultContactFormEmail" className="form-control mb-4" placeholder="E-mail" />
              <label>Subject</label>
              <select className="browser-default custom-select mb-4">
                <option value disabled>Choose option</option>
                <option value={1} selected>Feedback</option>
                <option value={2}>Report a bug</option>
                <option value={3}>Feature request</option>
                <option value={4}>Feature request</option>
              </select>
              <div className="form-group">
                <textarea className="form-control rounded-0" id="exampleFormControlTextarea2" rows={3} placeholder="Message" defaultValue={""} />
              </div>
              <div className="custom-control custom-checkbox mb-4">
                <input type="checkbox" className="custom-control-input" id="defaultContactFormCopy" />
                <label className="custom-control-label" htmlFor="defaultContactFormCopy">Send me a copy of this message</label>
              </div>
              <button className="btn btn-info btn-block" type="submit">Send</button>
            </form>

          </div>

          <div className="container col-6 map1">
            <div className="row-6 justify-content-center d-flex">
              <iframe src="https://www.google.com/maps/embed?pb=!1m16!1m12!1m3!1d197169.4690893715!2d72.9468073523536!3d19.062373486276574!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!2m1!1scar%20rental!5e0!3m2!1sen!2sin!4v1678004651065!5m2!1sen!2sin" width={400} height={350} style={{ border: 0 }} allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />


            </div>
            <div className=" row-6 ">
              <div className="row" style={{ display: 'block', marginLeft: 'auto', marginRight: 'auto', width: '70%' }}>
                <h6 className="text-uppercase fw-bold mb-4">Contact</h6>
                <p><i className="fas fa-home me-3 text-secondary" />SANTCRUZ, MUMBAI 400010, MH</p>
                <p>
                  <i className="fas fa-envelope me-3 text-secondary" />
                  info@example.com
                </p>
                <p><i className="fas fa-phone me-3 text-secondary" /> + 01 234 567 88</p>
                <p><i className="fas fa-print me-3 text-secondary" /> + 01 234 567 89</p>
              </div>
            </div>            
          </div>
        </div>
      </div>
      <div>
     </div> */}
    </>
  )
};

ContactUs.propTypes = {}

export default ContactUs;