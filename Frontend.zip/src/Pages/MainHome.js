import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import Home from "./Home";
import CarListAll from './CarListAll';
import CarDetails from './CarDetails';

function MainHome() {
  return (
    <>
    
      <Home></Home>

    <br></br>
      <h1>WELCOME User....</h1>
      <br></br>

      <CarListAll></CarListAll>
      <CarDetails></CarDetails>

      <br />
      
    </>
  );
}

export default MainHome;